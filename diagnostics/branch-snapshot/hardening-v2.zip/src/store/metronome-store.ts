import { create } from 'zustand';
import { subscribeWithSelector } from 'zustand/middleware';
import { VolumeState } from '../audio/types';
import type { MetronomeState } from './types';
import { createDefaultTrack } from './types';
import { clampBpm, getBeatGrouping } from '../utils/timing';
import {
  BPM_DEFAULT,
  DEFAULT_METER_NUMERATOR,
  DEFAULT_METER_DENOMINATOR,
  DEFAULT_SUBDIVISION,
  DEFAULT_VOLUME,
} from '../utils/constants';

export const useMetronomeStore = create<MetronomeState>()(subscribeWithSelector((set, get) => ({
  // Playback
  playing: false,
  bpm: BPM_DEFAULT,
  meterNumerator: DEFAULT_METER_NUMERATOR,
  meterDenominator: DEFAULT_METER_DENOMINATOR,
  beatGrouping: getBeatGrouping(DEFAULT_METER_NUMERATOR, DEFAULT_METER_DENOMINATOR),
  subdivision: DEFAULT_SUBDIVISION,
  volume: DEFAULT_VOLUME,

  // Tracks
  tracks: [createDefaultTrack(DEFAULT_METER_NUMERATOR, DEFAULT_SUBDIVISION)],

  // Beat animation
  currentBeats: {},

  // Bar counter + session timer
  currentBar: 0,
  playStartTime: 0,

  // Trainer
  trainerEnabled: false,
  trainerStartBpm: 80,
  trainerEndBpm: 140,
  trainerBpmStep: 5,
  trainerBarsPerStep: 4,

  // Count-in
  countInBars: 0,

  // Practice modes
  gapClickEnabled: false,
  gapClickProbability: 0.3,
  randomMuteEnabled: false,
  randomMuteProbability: 0.25,
  playMuteCycleEnabled: false,
  playMuteCyclePlayBars: 4,
  playMuteCycleMuteBars: 4,

  // Swing
  swing: 0,

  // ─── Actions ───

  setPlaying: (playing) => set({ playing }),

  setBpm: (bpm) => set({ bpm: clampBpm(bpm) }),

  adjustBpm: (delta) => {
    const { bpm } = get();
    set({ bpm: clampBpm(bpm + delta) });
  },

  setMeter: (numerator, denominator) => {
    const grouping = getBeatGrouping(numerator, denominator);
    const { subdivision, tracks } = get();
    const newTrack0 = createDefaultTrack(numerator, subdivision, 'track-0', grouping);
    const extraTracks = tracks.filter(t => t.id !== 'track-0');
    set({
      meterNumerator: numerator,
      meterDenominator: denominator,
      beatGrouping: grouping,
      tracks: [newTrack0, ...extraTracks],
    });
  },


  setGrouping: (grouping) => {
    const { meterNumerator, subdivision, tracks } = get();
    const newTrack0 = createDefaultTrack(meterNumerator, subdivision, 'track-0', grouping);
    const extraTracks = tracks.filter(t => t.id !== 'track-0');
    set({ beatGrouping: grouping, tracks: [newTrack0, ...extraTracks] });
  },
  setSubdivision: (sub) => {
    const { meterNumerator, beatGrouping, tracks } = get();
    const newTrack0 = createDefaultTrack(meterNumerator, sub, 'track-0', beatGrouping);
    const extraTracks = tracks.filter(t => t.id !== 'track-0');
    set({
      subdivision: sub,
      tracks: [newTrack0, ...extraTracks],
    });
  },

  setVolume: (vol) => set({ volume: Math.max(0, Math.min(1, vol)) }),

  setSwing: (swing) => set({ swing: Math.max(0, Math.min(1, swing)) }),

  setCurrentBeat: (trackId, index) => {
    const { currentBeats } = get();
    set({ currentBeats: { ...currentBeats, [trackId]: index } });
  },

  setCurrentBar: (bar) => set({ currentBar: bar }),

  setPlayStartTime: (time) => set({ playStartTime: time }),

  updateTrackAccent: (trackId, beatIndex) => {
    const { tracks } = get();
    const updated = tracks.map((t) => {
      if (t.id !== trackId) return t;
      const newAccents = [...t.accents];
      const current = newAccents[beatIndex];
      const next = current >= VolumeState.ACCENT ? VolumeState.OFF : (current + 1) as VolumeState;
      newAccents[beatIndex] = next;
      return { ...t, accents: newAccents };
    });
    set({ tracks: updated });
  },

  setTrackSound: (trackId, soundId, isAccent) => {
    const { tracks } = get();
    const updated = tracks.map((t) => {
      if (t.id !== trackId) return t;
      return isAccent ? { ...t, accentSound: soundId } : { ...t, normalSound: soundId };
    });
    set({ tracks: updated });
  },

  setTrackMuted: (trackId, muted) => {
    const { tracks } = get();
    set({ tracks: tracks.map(t => t.id === trackId ? { ...t, muted } : t) });
  },

  setTrackSwing: (trackId, swing) => {
    const { tracks } = get();
    set({ tracks: tracks.map(t => t.id === trackId ? { ...t, swing: Math.max(0, Math.min(1, swing)) } : t) });
  },

  setBeatSound: (trackId, beatIndex, soundId) => {
    const { tracks } = get();
    const updated = tracks.map((t) => {
      if (t.id !== trackId) return t;
      const newOverrides = { ...t.soundOverrides };
      if (soundId === null) {
        delete newOverrides[beatIndex];
      } else {
        newOverrides[beatIndex] = soundId;
      }
      return { ...t, soundOverrides: newOverrides };
    });
    set({ tracks: updated });
  },

  setAllSubdivisionVolume: (volume) => {
    const { tracks, subdivision } = get();
    if (subdivision <= 1) return; // no subdivisions to change
    const updated = tracks.map((t) => {
      if (t.id !== 'track-0') return t;
      const newAccents = [...t.accents];
      for (let i = 0; i < newAccents.length; i++) {
        // Only change subdivision cells (not main beats)
        if (i % subdivision !== 0) {
          newAccents[i] = volume;
        }
      }
      return { ...t, accents: newAccents };
    });
    set({ tracks: updated });
  },

  addTrack: (beats) => {
    const { tracks } = get();
    if (tracks.length >= 4) return; // max 4 tracks
    // Pick the first free index — array length alone would collide with
    // surviving IDs after a mid-list removal (add 1,2 → remove 1 → add
    // would duplicate 'track-2').
    let idx = tracks.length;
    while (tracks.some((t) => t.id === `track-${idx}`)) idx++;
    const id = `track-${idx}`;
    const accents: VolumeState[] = [];
    for (let i = 0; i < beats; i++) {
      accents.push(i === 0 ? VolumeState.ACCENT : VolumeState.LOUD);
    }
    // Each poly track gets a distinct default sound
    const defaultSounds = ['clave', 'cowbell', 'rimshot'];
    const sound = defaultSounds[(idx - 1) % defaultSounds.length];
    const newTrack = {
      id,
      beats,
      accents,
      normalSound: sound,
      normalVolume: 1,
      accentSound: sound,
      accentVolume: 2,
      muted: false,
      swing: 0,
      soundOverrides: {},
    };
    set({ tracks: [...tracks, newTrack] });
  },

  removeTrack: (trackId) => {
    const { tracks } = get();
    if (tracks.length <= 1) return;
    set({ tracks: tracks.filter(t => t.id !== trackId) });
  },

  setTrainerEnabled: (enabled) => {
    const { bpm } = get();
    set({
      trainerEnabled: enabled,
      ...(enabled ? { trainerStartBpm: bpm } : {}),
    });
  },

  setTrainerConfig: (config) => set(config),

  setCountInBars: (bars) => set({ countInBars: Math.max(0, Math.min(8, bars)) }),

  setGapClick: (enabled, probability) => set({
    gapClickEnabled: enabled,
    ...(probability !== undefined ? { gapClickProbability: probability } : {}),
  }),

  setRandomMute: (enabled, probability) => set({
    randomMuteEnabled: enabled,
    ...(probability !== undefined ? { randomMuteProbability: probability } : {}),
  }),

  setPlayMuteCycle: (enabled, playBars, muteBars) => set({
    playMuteCycleEnabled: enabled,
    ...(playBars !== undefined ? { playMuteCyclePlayBars: playBars } : {}),
    ...(muteBars !== undefined ? { playMuteCycleMuteBars: muteBars } : {}),
  }),

  resetToDefaults: () => {
    set({
      playing: false,
      bpm: BPM_DEFAULT,
      meterNumerator: DEFAULT_METER_NUMERATOR,
      meterDenominator: DEFAULT_METER_DENOMINATOR,
      beatGrouping: getBeatGrouping(DEFAULT_METER_NUMERATOR, DEFAULT_METER_DENOMINATOR),
      subdivision: DEFAULT_SUBDIVISION,
      volume: DEFAULT_VOLUME,
      tracks: [createDefaultTrack(DEFAULT_METER_NUMERATOR, DEFAULT_SUBDIVISION)],
      currentBeats: {},
      currentBar: 0,
      playStartTime: 0,
      trainerEnabled: false,
      countInBars: 0,
      gapClickEnabled: false,
      randomMuteEnabled: false,
      playMuteCycleEnabled: false,
      swing: 0,
    });
  },
})));
